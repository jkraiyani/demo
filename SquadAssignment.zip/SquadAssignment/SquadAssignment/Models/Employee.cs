﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SquadAssignment.Models
{
    public enum Desg 
    { 
        JrDeveloper = 1,
        SrDeveloper = 2,
        TeamLead = 3,
        ProjectLead = 4
    };
    public enum Languages
    {
        MVC = 1,
        VB,
        SQL,
        Jquery,
        JavaScript,
        AngularJS,
        NodeJS
    }
    public class Employee
    {
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; } = string.Empty;
        public string? LastName { get; set; } = string.Empty;
        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Please enter valid doubleNumber")]
        public double Salary { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = false)]
        [Display(Name ="Joining Date")]
        public DateTime JoiningDate { get; set; }
        [Display(Name = "Reporting To")]
        public int? ReportingId { get; set; }
        public Employee? ReportingEmployee { get; set; }
        [Required]
        public int DepartmentId { get; set; }
        [ForeignKey("DepartmentId")]
        public virtual Department? Department { get; set; }
        [Required]
        public Desg Designation { get; set; }
        public bool IsDeleted { get; set; } = false;
    }
}
