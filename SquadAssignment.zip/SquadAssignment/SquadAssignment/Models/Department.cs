﻿using System.ComponentModel.DataAnnotations;

namespace SquadAssignment.Models
{
    public class Department
    {
        [Key]
        public int DepartmentId { get; set; }
        [Required]
        public string DepartmentName { get; set; } = string.Empty;
        public bool IsDeleted { get; set; } = false;
        public ICollection<Employee> Employees { get; set; }
    }
}
