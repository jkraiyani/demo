﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SquadAssignment.Migrations
{
    /// <inheritdoc />
    public partial class ReportingManager : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "ReportingId",
                table: "Employees",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_ReportingId",
                table: "Employees",
                column: "ReportingId");

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Employees_ReportingId",
                table: "Employees",
                column: "ReportingId",
                principalTable: "Employees",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Employees_ReportingId",
                table: "Employees");

            migrationBuilder.DropIndex(
                name: "IX_Employees_ReportingId",
                table: "Employees");

            migrationBuilder.AlterColumn<int>(
                name: "ReportingId",
                table: "Employees",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}
