﻿using SquadAssignment.Data;
using SquadAssignment.Models;
using SquadAssignment.Services.Interfaces;

namespace SquadAssignment.Services.Repositories
{
    public class DepartmentRepository : IDepartment
    {
        private readonly DataDbContext _department;

        public DepartmentRepository(DataDbContext department)
        {
            _department = department;
        }
        public void AddOrUpdateDepartment(int id, Department departmentData)
        {
            var data = GetSingleDepartment(id);
            if (data != null)
            {
                data.DepartmentName = departmentData.DepartmentName;
                _department.SaveChanges();
            }
            else
            {
                _department.Departments.Add(departmentData);
                _department.SaveChanges();
            }
        }

        public List<Department> GetDepartments()
        {
            var data = _department.Departments.Where(x => !x.IsDeleted).ToList();
            return data;
        }

        public Department? GetSingleDepartment(int id)
        {
            var data = _department.Departments.FirstOrDefault(x => x.DepartmentId == id);
            return data;
        }

        public void RemoveDepartment(int id)
        {
            var data = GetSingleDepartment(id);
            data.IsDeleted = true;
            _department.SaveChanges();
        }
    }
}
