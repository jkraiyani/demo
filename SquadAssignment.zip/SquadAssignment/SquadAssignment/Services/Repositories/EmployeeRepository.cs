﻿using Microsoft.EntityFrameworkCore;
using SquadAssignment.Data;
using SquadAssignment.Models;
using SquadAssignment.Services.Interfaces;

namespace SquadAssignment.Services.Repositories
{
    public class EmployeeRepository : IEmployee
    {
        private readonly DataDbContext _employee;

        public EmployeeRepository(DataDbContext employee)
        {
            _employee = employee;
        }
        public List<Employee> GetEmployees()
        {
            var result = _employee.Employees.Include(x => x.Department).Include(x => x.ReportingEmployee).Where(x=>!x.IsDeleted).ToList();
            return result;
        }
        public Employee? GetSingleEmployee(int id)
        {
            var data = _employee.Employees.Include(x => x.Department).FirstOrDefault(x => x.Id == id);
            return data;
        }
        public void AddOrUpdateEmployee(int id, Employee employeeData)
        {
            var data = GetSingleEmployee(id);
            if (data != null)
            {
                data.FirstName = employeeData.FirstName;
                data.LastName = employeeData.LastName;
                data.Salary = employeeData.Salary;
                data.Designation = employeeData.Designation;
                data.DepartmentId = employeeData.DepartmentId;
                data.ReportingId = employeeData.ReportingId;
                data.JoiningDate = employeeData.JoiningDate;
                _employee.SaveChanges();
            }
            else
            {
                _employee.Employees.Add(employeeData);
                _employee.SaveChanges();
            }
        }
        public void RemoveEmployee(int id)
        {
            var data = GetSingleEmployee(id);
            data.IsDeleted = true;
            _employee.SaveChanges();
        }
    }
}
