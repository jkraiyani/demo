﻿using SquadAssignment.Models;

namespace SquadAssignment.Services.Interfaces
{
    public interface IDepartment
    {
        Department? GetSingleDepartment(int id);
        List<Department> GetDepartments();
        void AddOrUpdateDepartment(int id, Department departmentData);
        void RemoveDepartment(int id);
    }
}
