﻿using SquadAssignment.Models;

namespace SquadAssignment.Services.Interfaces
{
    public interface IEmployee
    {
        Employee? GetSingleEmployee(int id);
        List<Employee> GetEmployees();
        void AddOrUpdateEmployee(int id, Employee employeeData);
        void RemoveEmployee(int id);
    }
}
