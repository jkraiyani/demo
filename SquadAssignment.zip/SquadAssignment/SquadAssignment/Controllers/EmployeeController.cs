﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using System.Windows.Input;
using SquadAssignment.Services.Interfaces;
using SquadAssignment.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace SquadAssignment.Controllers
{
    public class EmployeeController : Controller
    {
        int flag = 0;
        private readonly IEmployee _employeeService;
        private readonly IDepartment _departmentService;
        private readonly ILogger<EmployeeController> _logger;

        public EmployeeController(IEmployee employeeServices, IDepartment departmentService, ILogger<EmployeeController> logger)
        {
            _employeeService = employeeServices;
            _departmentService = departmentService;
            _logger = logger;
        }

        // GET: Employee
        public IActionResult Index(string sortOrder, string searchString, DateTime? fromDate, DateTime? toDate, int page = 1, int pageSize = 10)
        {
            _logger.LogInformation("Employee data is Fethed from Index.");
            if (sortOrder == "nameDesc")
            {
                flag = 1;
            }
            else if (sortOrder == "nameAsc")
            {
                flag = 0;
            }
            TempData["NameSortParm"] = flag == 0 ? "nameDesc" : "nameAsc";
            ViewData["CurrentFilter"] = searchString;
            ViewData["fromDate"] = fromDate;
            ViewData["toDate"] = toDate;
            TempData["SearchQuery"] = searchString;

            var totalCount = _employeeService.GetEmployees().Count();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            ViewBag.Page = page;
            ViewBag.TotalPages = totalPages;

            var result = _employeeService.GetEmployees();

            if (!String.IsNullOrEmpty(searchString))
            {
                result = result.Where(s => s.FirstName.Contains(searchString)
                                       || s.Department.DepartmentName.ToLower().Contains(searchString.ToLower())).ToList();
            }
            switch (sortOrder)
            {
                case "nameDesc":
                    result = result.Skip((page - 1) * pageSize).Take(pageSize).OrderByDescending(s => s.FirstName).ToList();
                    break;
                case "nameAsc":
                    result = result.Skip((page - 1) * pageSize).Take(pageSize).OrderBy(s => s.FirstName).ToList();
                    break;
                default:
                    if (fromDate.HasValue && toDate.HasValue)
                    {
                        result = result.Where(e => e.JoiningDate >= fromDate.Value && e.JoiningDate <= toDate.Value).Skip((page - 1) * pageSize).Take(pageSize).OrderBy(s => s.Id).ToList();
                    }
                    else if(fromDate.HasValue && !toDate.HasValue)
                    {
                        result = result.Where(e => e.JoiningDate >= fromDate.Value && e.JoiningDate <= DateTime.Now).Skip((page - 1) * pageSize).Take(pageSize).OrderBy(s => s.Id).ToList();
                    }
                    else
                    {
                        result = result.Skip((page - 1) * pageSize).Take(pageSize).OrderBy(s => s.Id).ToList();
                    }                       
                    break;
            }
            return View(result);
        }

        // GET: Employee/Details/5
        public IActionResult Details(int? id)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Employee data is viewd from Details.");
                var company = _employeeService.GetSingleEmployee((int)id);
                return View(company);
            }
            return View();
        }

        // GET: Employee/Create
        public IActionResult Create()
        {
            ViewBag.Departments = new SelectList(_departmentService.GetDepartments(), "DepartmentId", "DepartmentName");
            ViewBag.Reporting = new SelectList(_employeeService.GetEmployees(), "Id", "FirstName");
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id, FirstName,LastName, Salary, JoiningDate, ReportingId, DepartmentId, Designation")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Employee data is Added.");
                _employeeService.AddOrUpdateEmployee(employee.Id, employee);
                TempData["Message"] = "<script>swal('Created Successfully', '', 'success');</script>";
                return RedirectToAction(nameof(Index));
            }
            ViewBag.Departments = new SelectList(_departmentService.GetDepartments(), "DepartmentId", "DepartmentName");
            ViewBag.Reporting = new SelectList(_employeeService.GetEmployees(), "Id", "FirstName");
            return View();
        }

        // GET: Employee/Edit/5
        public IActionResult Edit(int? id)
        {
            _logger.LogInformation("Fetched Employee data");
            var employee = _employeeService.GetSingleEmployee((int)id);
            ViewBag.Departments = new SelectList(_departmentService.GetDepartments(), "DepartmentId", "DepartmentName");
            ViewBag.Reporting = new SelectList(_employeeService.GetEmployees(), "Id", "FirstName");
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind("Id, FirstName,LastName, Salary, JoiningDate, ReportingId, DepartmentId, Designation")] int id, Employee employee)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Employee data is Modified.");
                _employeeService.AddOrUpdateEmployee(employee.Id, employee);
                TempData["Message"] = "<script>swal('Edited Successfully', '', 'success');</script>";
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Employee/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            _logger.LogInformation("Employee data is Deleted.");
            _employeeService.RemoveEmployee((int)id);
            TempData["Message"] = "<script>swal('Deleted Successfully', 'You clicked the button!', 'success');</script>";
            return RedirectToAction(nameof(Index));
        }
    }
}
