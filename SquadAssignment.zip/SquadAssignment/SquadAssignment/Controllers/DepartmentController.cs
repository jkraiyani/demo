﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SquadAssignment.Models;
using SquadAssignment.Services.Interfaces;

namespace SquadAssignment.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly IDepartment _departmentService;
        private readonly ILogger<DepartmentController> _logger;

        public DepartmentController(IDepartment departmentServices, ILogger<DepartmentController> logger)
        {
            _departmentService = departmentServices;
            _logger = logger;
        }

        // GET: Department
        public async Task<IActionResult> Index()
        {
            _logger.LogInformation("Department data is Fethed from Index.");
            var data = _departmentService.GetDepartments();
            return View(data);
        }

        // GET: Department/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Department data is viewd from Details.");
                var company = _departmentService.GetSingleDepartment((int)id);
                return View(company);
            }
            return View();
        }

        // GET: Company/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Department/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Department department)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Department data is Added.");
                _departmentService.AddOrUpdateDepartment(department.DepartmentId, department);
                TempData["Message"] = "<script>swal('Created Successfully', '', 'success');</script>";
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Department/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            _logger.LogInformation("Fetched Department data");
            var Department = _departmentService.GetSingleDepartment((int)id);
            if (Department == null)
            {
                return NotFound();
            }
            return View(Department);
        }

        // POST: Department/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Department department)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Department data is Modified.");
                _departmentService.AddOrUpdateDepartment(department.DepartmentId, department);
                TempData["Message"] = "<script>swal('Edited Successfully', '', 'success');</script>";
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Department/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            _logger.LogInformation("Department data is Deleted.");
            _departmentService.RemoveDepartment((int)id);
            TempData["Message"] = "<script>swal('Deleted Successfully', 'You clicked the button!', 'success');</script>";
            return RedirectToAction(nameof(Index));
        }
    }
}
