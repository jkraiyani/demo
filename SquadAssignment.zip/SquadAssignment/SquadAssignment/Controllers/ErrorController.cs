﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace SquadAssignment.Controllers
{
    public class ErrorController : Controller
    {
        private readonly ILogger<ErrorController> _logger;

        public ErrorController(ILogger<ErrorController> logger)
        {
            _logger = logger;
        }

        [HttpGet("/Error")]
        public IActionResult Index()
        {
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
            IExceptionHandlerPathFeature iExceptionHandlerFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
            if (iExceptionHandlerFeature != null)
            {
                string path = iExceptionHandlerFeature.Path;
                Exception exception = iExceptionHandlerFeature.Error;
                //Write code here to log the exception details
                _logger.LogError($"Error Occurred at Location {path} and exception is {exception}.");
                return View("Error", iExceptionHandlerFeature);
            }
            return View();
        }
        [HttpGet("/Error/NotFound/{statusCode}")]
        public IActionResult NotFound(int statusCode)
        {
            var iStatusCodeReExecuteFeature = HttpContext.Features.Get<IStatusCodeReExecuteFeature>();
            return View("NotFound", iStatusCodeReExecuteFeature.OriginalPath);
        }
    }
}
